def subdemoprint():
    print("Now in the subdemo package")