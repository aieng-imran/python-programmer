def demoprint():
    print("it's a demo file!")